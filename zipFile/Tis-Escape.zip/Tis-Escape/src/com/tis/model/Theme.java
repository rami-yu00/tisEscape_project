package com.tis.model;

public class Theme {
    
   private String tmcode;
   private String theme;
   private String content;
   private String img;
   private int rating;
   private int difficulty;
   private int headcount;
   private int price;
   
   private String ti_tmcode;

private String h1; private String h2; private String h3; private String h4;
private String h5; private String h6; private String h7; private String h8;
private String h9;


//-------- theme -----------   
public String getTheme() { return theme; }
public String getTmcode() { return tmcode; }
public void setTmcode(String tmcode) { this.tmcode = tmcode; }
public void setTheme(String theme) { this.theme = theme; }
public String getContent() { return content; }
public void setContent(String content) { this.content = content; }
public String getImg() {  return img; }
public void setImg(String img) { this.img = img; }
public int getRating() { return rating; }
public void setRating(int rating) { this.rating = rating; }
public int getDifficulty() { return difficulty; }
public void setDifficulty(int difficulty) { this.difficulty = difficulty; }
public int getHeadcount() { return headcount; }
public void setHeadcount(int headcount) {  this.headcount = headcount; }
public int getPrice() { return price; }
public void setPrice(int price) {  this.price = price; }
//-------- rsv_times -----------
public String getTi_tmcode() {
    return ti_tmcode;
}
public void setTi_tmcode(String ti_tmcode) {
    this.ti_tmcode = ti_tmcode;
}
public String getH1() {
    return h1;
}
public void setH1(String h1) {
    this.h1 = h1;
}
public String getH2() {
    return h2;
}
public void setH2(String h2) {
    this.h2 = h2;
}
public String getH3() {
    return h3;
}
public void setH3(String h3) {
    this.h3 = h3;
}
public String getH4() {
    return h4;
}
public void setH4(String h4) {
    this.h4 = h4;
}
public String getH5() {
    return h5;
}
public void setH5(String h5) {
    this.h5 = h5;
}
public String getH6() {
    return h6;
}
public void setH6(String h6) {
    this.h6 = h6;
}
public String getH7() {
    return h7;
}
public void setH7(String h7) {
    this.h7 = h7;
}
public String getH8() {
    return h8;
}
public void setH8(String h8) {
    this.h8 = h8;
}
public String getH9() {
    return h9;
}
public void setH9(String h9) {
    this.h9 = h9;
}



}//class END
